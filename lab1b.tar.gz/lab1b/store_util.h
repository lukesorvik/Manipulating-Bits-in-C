// Written by Porter Jones (pbjones@cs.washington.edu)

#ifndef _STORE_UTIL_H
#define _STORE_UTIL_H

// Definitions for debugging functions
void print_binary_short(unsigned short);
void print_binary_long(unsigned long);

#endif  // _STORE_UTIL_H
